# Futurama system model


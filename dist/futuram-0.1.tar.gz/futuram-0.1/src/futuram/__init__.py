__path__ = extend_path(__path__, __name__)

from setuptools import setup

setup(name='futuram',
      version='0.1',
      description='SRM recovery model for the FutuRaM project',
      url='https://github.com/FutuRaM-Project/IntegratedModel',
      author='FutuRaM',
      author_email='s.c.mcdowall@cml.leidenuniv.nl',
      license='MIT',
      packages=['src.futuram'],
      zip_safe=False)